import express  from "express";
import {estudiantes} from "./controlador/estudiantes.js"
const app_e = express() //nombre de la varible

app_e.use(express.static('./controlador')) //directorios estaticos directorios fuentes
app_e.use(express.static('./modelo'))
app_e.use(express.static('./vista'))
app_e.set('views','./vista')//defince directorios especiales que contiene clases, para el motor de vistas web
app_e.set('view engine','ejs');//motor de busqueda (vista ejs)

app_e.listen('5000',function(){  //dispara el servidor donde se puede ver la pagina web
console.log("aplicacion esta iniciada : http://localhost:5000")
}) 


app_e.get('/', estudiantes.js.leer);