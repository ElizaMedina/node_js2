import  Express  from "express";
import {conectar} from "../modelo/db_conectar.js"
var estudiantese =({});
estudiantes.leer = (req,res)=>{
   
    conectar.query('SELECT id_estudiante,carnet,nombres,apellidos,direccion,telefono,correo_electronico,sangre,date_format(fecha_nacimiento,"%d-%m-%y") FROM estudiantes;',(error,results)=>{
        if (error){
                throw error;

        }else{
            res.render('estudiantes/index', {resultado:results})
        }
    })
};
export{estudiantes}