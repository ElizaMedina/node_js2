import { application } from 'express';
import Mysql from 'mysql';
var conectar = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '4912',
    database : 'db_medina'
});
conectar.connect(function(err){
if(err){
    console.error('error en la concexion:' + err.stack)
    return;
}
console.log('conexion exitosa ID:' + conectar.threadId);

});
export{conectar}